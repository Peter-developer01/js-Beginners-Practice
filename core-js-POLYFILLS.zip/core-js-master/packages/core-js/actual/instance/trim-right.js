var parent = require('../../stable/instance/trim-right');

module.exports = parent;
