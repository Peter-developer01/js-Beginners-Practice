var parent = require('../../stable/instance/last-index-of');

module.exports = parent;
