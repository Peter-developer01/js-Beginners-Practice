var parent = require('../../stable/instance/pad-end');

module.exports = parent;
