var parent = require('../../stable/instance/reduce-right');

module.exports = parent;
