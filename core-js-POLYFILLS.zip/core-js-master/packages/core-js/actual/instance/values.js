var parent = require('../../stable/instance/values');

module.exports = parent;
