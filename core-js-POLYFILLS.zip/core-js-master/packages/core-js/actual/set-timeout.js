var parent = require('../stable/set-timeout');

module.exports = parent;
