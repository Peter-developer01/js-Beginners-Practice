var parent = require('../../stable/json');

module.exports = parent;
