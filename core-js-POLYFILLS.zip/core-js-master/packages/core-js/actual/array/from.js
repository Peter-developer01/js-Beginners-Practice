var parent = require('../../stable/array/from');

module.exports = parent;
