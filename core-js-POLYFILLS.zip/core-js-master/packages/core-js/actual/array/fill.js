var parent = require('../../stable/array/fill');

module.exports = parent;
