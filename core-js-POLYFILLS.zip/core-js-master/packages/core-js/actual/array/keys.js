var parent = require('../../stable/array/keys');

module.exports = parent;
