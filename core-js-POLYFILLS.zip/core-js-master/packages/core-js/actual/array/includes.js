var parent = require('../../stable/array/includes');

module.exports = parent;
