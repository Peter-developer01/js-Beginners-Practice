require('../../modules/es.map');
require('../../modules/es.object.to-string');
require('../../modules/esnext.array.group-to-map');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'groupToMap');
