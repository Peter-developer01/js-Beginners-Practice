var parent = require('../../stable/array/at');

module.exports = parent;
