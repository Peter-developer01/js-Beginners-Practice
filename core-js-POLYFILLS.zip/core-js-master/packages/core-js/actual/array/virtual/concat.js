var parent = require('../../../stable/array/virtual/concat');

module.exports = parent;
