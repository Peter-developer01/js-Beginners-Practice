var parent = require('../../../stable/array/virtual/reduce');

module.exports = parent;
