var parent = require('../../../stable/array/virtual/filter');

module.exports = parent;
