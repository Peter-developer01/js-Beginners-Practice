require('../../../modules/esnext.array.group-by');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').groupBy;
