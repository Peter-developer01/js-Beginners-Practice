var parent = require('../../../stable/array/virtual/push');

module.exports = parent;
