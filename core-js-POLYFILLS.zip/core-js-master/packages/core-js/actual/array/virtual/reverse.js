var parent = require('../../../stable/array/virtual/reverse');

module.exports = parent;
