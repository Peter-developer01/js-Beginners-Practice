require('../../../modules/es.array.sort');
require('../../../modules/esnext.array.to-sorted');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').toSorted;
