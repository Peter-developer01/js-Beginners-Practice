require('../../modules/esnext.array.group');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'group');
