var parent = require('../../stable/math/log10');

module.exports = parent;
