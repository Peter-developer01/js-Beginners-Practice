var parent = require('../../stable/math/imul');

module.exports = parent;
