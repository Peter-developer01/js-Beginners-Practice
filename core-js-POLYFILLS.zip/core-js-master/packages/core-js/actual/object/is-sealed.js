var parent = require('../../stable/object/is-sealed');

module.exports = parent;
