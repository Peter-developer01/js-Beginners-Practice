var parent = require('../../stable/object/entries');

module.exports = parent;
