var parent = require('../../stable/object/define-properties');

module.exports = parent;
