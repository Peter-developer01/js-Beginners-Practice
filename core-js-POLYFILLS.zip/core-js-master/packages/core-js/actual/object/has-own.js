var parent = require('../../stable/object/has-own');

module.exports = parent;
