var parent = require('../../stable/object/get-own-property-names');

module.exports = parent;
