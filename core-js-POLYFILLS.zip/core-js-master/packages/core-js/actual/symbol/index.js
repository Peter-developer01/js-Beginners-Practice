var parent = require('../../stable/symbol');

module.exports = parent;
