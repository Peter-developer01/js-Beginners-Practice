var parent = require('../stable/aggregate-error');

module.exports = parent;
