var parent = require('../../stable/reflect/set-prototype-of');

module.exports = parent;
