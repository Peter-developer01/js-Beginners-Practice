var parent = require('../../stable/function/bind');

module.exports = parent;
