var parent = require('../stable/global-this');

module.exports = parent;
