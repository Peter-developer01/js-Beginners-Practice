var parent = require('../../stable/string/from-code-point');

module.exports = parent;
