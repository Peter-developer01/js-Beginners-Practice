var parent = require('../../stable/string/sub');

module.exports = parent;
