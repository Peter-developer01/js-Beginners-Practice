var parent = require('../../stable/string/fontcolor');

module.exports = parent;
