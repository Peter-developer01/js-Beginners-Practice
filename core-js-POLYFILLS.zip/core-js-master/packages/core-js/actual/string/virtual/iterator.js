var parent = require('../../../stable/string/virtual/iterator');

module.exports = parent;
