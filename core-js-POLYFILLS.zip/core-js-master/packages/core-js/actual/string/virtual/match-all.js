var parent = require('../../../stable/string/virtual/match-all');

module.exports = parent;
