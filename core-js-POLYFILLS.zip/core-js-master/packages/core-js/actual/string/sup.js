var parent = require('../../stable/string/sup');

module.exports = parent;
