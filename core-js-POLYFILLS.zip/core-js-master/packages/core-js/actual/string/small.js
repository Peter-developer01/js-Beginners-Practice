var parent = require('../../stable/string/small');

module.exports = parent;
