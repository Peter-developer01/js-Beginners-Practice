var parent = require('../../stable/string/link');

module.exports = parent;
