var parent = require('../../stable/string/replace');

module.exports = parent;
