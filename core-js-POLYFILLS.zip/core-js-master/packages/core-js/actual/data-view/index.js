var parent = require('../../stable/data-view');

module.exports = parent;
