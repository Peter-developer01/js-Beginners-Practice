var getIterator = require('../internals/get-iterator');

module.exports = getIterator;
