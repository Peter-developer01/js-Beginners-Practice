module.exports = function (value) {
  return value;
};
