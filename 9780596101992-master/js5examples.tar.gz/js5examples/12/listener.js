function keyPressed(e) {
    print("key pressed: " + String.fromCharCode(e.getKeyChar()));
}
function keyReleased(e) { /* do nothing */ }
function keyTyped(e) { /* do nothing */ }
